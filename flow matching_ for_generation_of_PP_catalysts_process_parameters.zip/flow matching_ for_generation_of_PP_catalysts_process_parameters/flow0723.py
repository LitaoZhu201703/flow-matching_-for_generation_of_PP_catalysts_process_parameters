import tensorflow as tf
from tensorflow.keras import layers, Model
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import AdaBoostRegressor, BaggingRegressor, ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from bayes_opt import BayesianOptimization
import numpy as np
import shap
import matplotlib.pyplot as plt
from tensorboard.plugins.hparams import api as hp
import os
import time

class MyFlow:
    def __init__(self):
        self.scaler = None
        self.ohe = None
        
        self.dim_cont = 0
        self.dim_bin = 0
        self.dim_r1 = 0
        self.dim_r2 = 0


    def dataRead_cat(self, file_path, y_process=True):
        """
        Read data
        """
        print("Begining reading and processing")
        df = pd.read_csv(file_path, na_values=['/', ' ', ''])
        temp_col = 'T/℃' if 'T/℃' in df.columns else 'T/C'
        
        # Variable define
        continuous_x_cols = ['Cat(umol)', 'Al/M(molar)', 't/min', temp_col]
        binary_x_cols = ['M_Zr', 'M_Ti', 'M_Hf', 'R3']
        categorical_x_cols = ['R1对应编号', 'R2对应编号'] 
        y_cols = ['Activity(KgPP/mol cat)', 'Mn(×104g/mol）', 'PDI']
        
        used_cols = continuous_x_cols + binary_x_cols + categorical_x_cols + y_cols
        
        raw_len = len(df)
        df = df[used_cols].dropna()
        print(f"Original {raw_len} ，residual data after deleting uncomplete data {len(df)}。")
        
        df['R1对应编号'] = df['R1对应编号'].astype(float).astype(int).astype(str)
        df['R2对应编号'] = df['R2对应编号'].astype(float).astype(int).astype(str)
        
        x_cont = df[continuous_x_cols].astype(float).values
        x_bin = df[binary_x_cols].astype(float).values
        x_cat = df[categorical_x_cols].values
        
        # 1. Standardize continuous variables
        self.scaler = StandardScaler()
        x_cont_scaled = self.scaler.fit_transform(x_cont)
        self.dim_cont = x_cont_scaled.shape[1]
        
        # 2. One-hot embedding for categorical variables
        self.ohe = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
        x_cat_ohe = self.ohe.fit_transform(x_cat)
        
        self.dim_r1 = len(self.ohe.categories_[0])
        self.dim_r2 = len(self.ohe.categories_[1])
        self.dim_bin = x_bin.shape[1]
        
        # 3. Concat feature [Continues, binery, One-Hot]
        x = np.concatenate([x_cont_scaled, x_bin, x_cat_ohe], axis=1).astype(np.float32)
        
        print(f"Feature processing finished，total dimensional: {x.shape[1]} (continuous:{self.dim_cont}, binery value:{self.dim_bin}, R1:{self.dim_r1}, R2:{self.dim_r2})")

        # Y processing
        y_raw = df[y_cols].astype(float).values
        if y_process:
            y_ac = (y_raw[:, 0] >= 10000).astype(float)
            y_mn = (y_raw[:, 1] >= 50).astype(float)
            y_pdi = (y_raw[:, 2] <= 2.5).astype(float) 
            y = np.column_stack([y_ac, y_mn, y_pdi]).astype(np.float32)
            print("condition y is categorized to binery values")
        else:
            y = y_raw.astype(np.float32)
            print("y is continous values")
            
        return x, y    
    
    

    def datasetMaker(self, x, y, batch_size, x_disc_process=True):
        x_tensor = tf.cast(x, tf.float32)
        y_tensor = tf.cast(y, tf.float32)
        
        if x_disc_process:
            disc_start_idx = self.dim_cont
            noise = tf.random.uniform(shape=tf.shape(x_tensor[:, disc_start_idx:]), minval=-0.05, maxval=0.05)
            x_disc = x_tensor[:, disc_start_idx:] + noise
            x_tensor = tf.concat([x_tensor[:, :disc_start_idx], x_disc], axis=1)
            
        dataset = tf.data.Dataset.from_tensor_slices((x_tensor, y_tensor))
        dataset = dataset.shuffle(buffer_size=len(x), reshuffle_each_iteration=True)
        train_dataset = dataset.batch(batch_size, drop_remainder=True)
        train_dataset = train_dataset.prefetch(tf.data.AUTOTUNE)
        return train_dataset

    def modelTrain(self, x, y, epochs, record_dir, batch_size, lr, save_path, save_threshold=None, model=None):
        optimizer = tf.keras.optimizers.Adam(learning_rate=lr)
        train_dataset = self.datasetMaker(x, y, batch_size=batch_size, x_disc_process=True)
        
        input_dim = x.shape[1]
        condition_dim = y.shape[1]
        
        if model is None:
            print(f"init VectorFieldNet (input_dim: {input_dim}, cond_dim: {condition_dim})")
            model = VectorFieldNet(input_dim=input_dim, condition_dim=condition_dim)
        
        summary_writer = tf.summary.create_file_writer(record_dir)
        best_loss = float('inf')
        if save_threshold is None: save_threshold = float('inf') 
            
        save_dir = os.path.dirname(save_path)
        if save_dir and not os.path.exists(save_dir):
            os.makedirs(save_dir)

        print(f"\n================ Begin training ({epochs} epochs) ================")
        for epoch in range(epochs):
            start_time = time.time()
            epoch_loss_avg = tf.keras.metrics.Mean()
            
            for batch_idx, (x_batch, y_batch) in enumerate(train_dataset):
                loss = train_step(model, optimizer, x_batch, y_batch)
                epoch_loss_avg.update_state(loss)
                
            current_loss = epoch_loss_avg.result().numpy()
            epoch_time = time.time() - start_time
            
            with summary_writer.as_default():
                tf.summary.scalar('Loss', current_loss, step=epoch)
                
            print(f"Epoch {epoch+1:04d}/{epochs:04d} | Loss: {current_loss:.6f} | Time: {epoch_time:.2f}s", end="")
            
            if current_loss < best_loss:
                best_loss = current_loss
                if current_loss <= save_threshold:
                    model.save_weights(save_path)
                    print(f"  --> model are save to {save_path}")
            else:
                print()
        print("================ Finish training ================")
        summary_writer.flush() 
        return model


    def generative_func_cat(self, model, num, condition=(1, 1, 1), save_file_path=None):
        print(f"For condition {condition}, generate {num} candidates...")
        
        cond_tensor = tf.constant([condition], dtype=tf.float32)
        cond_batch = tf.tile(cond_tensor, [num, 1])
        
        generated_tensor = generate_samples(model, cond_batch, num_steps=50) 
        generated_raw = generated_tensor.numpy()
        
        
        idx_cont_end = self.dim_cont
        cont_scaled = generated_raw[:, 0:idx_cont_end]
        cont_real = self.scaler.inverse_transform(cont_scaled)
        cont_real = np.maximum(cont_real, 0.0) 
        
        
        idx_bin_end = idx_cont_end + self.dim_bin
        bin_raw = generated_raw[:, idx_cont_end:idx_bin_end]
        
        metal_weights = bin_raw[:, 0:3]
        metal_discrete = np.zeros_like(metal_weights)
        metal_discrete[np.arange(num), np.argmax(metal_weights, axis=1)] = 1.0
        
        r3_weight = bin_raw[:, 3:4]
        r3_discrete = (r3_weight >= 0.5).astype(float)
        
        idx_r1_end = idx_bin_end + self.dim_r1
        r1_weights = generated_raw[:, idx_bin_end:idx_r1_end]
        r1_ohe = np.zeros_like(r1_weights)
        r1_ohe[np.arange(num), np.argmax(r1_weights, axis=1)] = 1.0 
        
        idx_r2_end = idx_r1_end + self.dim_r2
        r2_weights = generated_raw[:, idx_r1_end:idx_r2_end]
        r2_ohe = np.zeros_like(r2_weights)
        r2_ohe[np.arange(num), np.argmax(r2_weights, axis=1)] = 1.0
        
        cat_ohe_combined = np.concatenate([r1_ohe, r2_ohe], axis=1)
        r_ids_str = self.ohe.inverse_transform(cat_ohe_combined)
        r_ids_discrete = r_ids_str.astype(float).astype(int)
        
        final_features = np.concatenate([cont_real, metal_discrete, r3_discrete, r_ids_discrete], axis=1)
        
        columns = ['Cat(umol)', 'Al/M(molar)', 't/min', 'T/C', 'M_Zr', 'M_Ti', 'M_Hf', 'R3', 'R1对应编号', 'R2对应编号']
        df_generated = pd.DataFrame(final_features, columns=columns)
        
        df_generated['Target_AC_Class'] = condition[0]
        df_generated['Target_Mn_Class'] = condition[1]
        df_generated['Target_PDI_Class'] = condition[2]
        
        if save_file_path is not None:
            df_generated.to_csv(save_file_path, index=False, encoding='utf-8-sig')
            print(f"Finished, save to : {save_file_path}")
            
        return df_generated
    

    def _build_constraint_mask_and_target(self, fixed_params_dict):

        cont_cols = ['Cat(umol)', 'Al/M(molar)', 't/min', 'T/C']
        cont_mock = np.zeros((1, 4))
        cont_mask = np.zeros(4, dtype=bool)
        
        bin_cols = ['M_Zr', 'M_Ti', 'M_Hf', 'R3']
        bin_mock = np.zeros(4)
        bin_mask = np.zeros(4, dtype=bool)
        
        # 3. 类别特征
        cat_cols = ['R1对应编号', 'R2对应编号']
        cat_mock = np.array([['1', '1']], dtype=object) 
        cat_lock_flags = [False, False] 
        
        for k, v in fixed_params_dict.items():
            if k == 'T/℃' and 'T/C' in cont_cols: k = 'T/C'
            
            if k in cont_cols:
                idx = cont_cols.index(k)
                cont_mock[0, idx] = float(v)
                cont_mask[idx] = True
            elif k in bin_cols:
                idx = bin_cols.index(k)
                bin_mock[idx] = float(v)
                bin_mask[idx] = True
            elif k in cat_cols:
                idx = cat_cols.index(k)
                cat_mock[0, idx] = str(int(float(v)))
                cat_lock_flags[idx] = True
                
        cont_target = self.scaler.transform(cont_mock)[0]
        cat_target_ohe = self.ohe.transform(cat_mock)[0]
        
        cat_mask = np.zeros(len(cat_target_ohe), dtype=bool)
        if cat_lock_flags[0]:
            cat_mask[0:self.dim_r1] = True
        if cat_lock_flags[1]:
            cat_mask[self.dim_r1 : self.dim_r1 + self.dim_r2] = True
            
        final_target = np.concatenate([cont_target, bin_mock, cat_target_ohe]).astype(np.float32)
        final_mask = np.concatenate([cont_mask, bin_mask, cat_mask]).astype(bool)
        
        return final_target, final_mask

    def constrained_generation_cat(self, model, num, condition=(1, 1, 1), fixed_params_dict=None, save_file_path=None):
        """
        fixed_params_dict example: {'T/C': 80.0, 'R1对应编号': 11}
        """
        if not fixed_params_dict:
            print("fixed_params are not provided, back to conditional generation。")
            return self.generative_func_cat(model, num, condition, save_file_path)

        print(f"Constrained generation...")
        
        target_vec, mask_vec = self._build_constraint_mask_and_target(fixed_params_dict)
        
        cond_tensor = tf.constant([condition], dtype=tf.float32)
        cond_batch = tf.tile(cond_tensor, [num, 1])
        
        target_batch = tf.tile(tf.constant([target_vec]), [num, 1])
        mask_batch = tf.tile(tf.constant([mask_vec]), [num, 1])
        
        generated_tensor = generate_samples_constrained(model, cond_batch, target_batch, mask_batch, num_steps=50) 
        generated_raw = generated_tensor.numpy()
        
        idx_cont_end = self.dim_cont
        cont_scaled = generated_raw[:, 0:idx_cont_end]
        cont_real = self.scaler.inverse_transform(cont_scaled)
        cont_real = np.maximum(cont_real, 0.0) 
        
        idx_bin_end = idx_cont_end + self.dim_bin
        bin_raw = generated_raw[:, idx_cont_end:idx_bin_end]
        metal_weights = bin_raw[:, 0:3]
        metal_discrete = np.zeros_like(metal_weights)
        metal_discrete[np.arange(num), np.argmax(metal_weights, axis=1)] = 1.0
        r3_weight = bin_raw[:, 3:4]
        r3_discrete = (r3_weight >= 0.5).astype(float)
        
        idx_r1_end = idx_bin_end + self.dim_r1
        r1_weights = generated_raw[:, idx_bin_end:idx_r1_end]
        r1_ohe = np.zeros_like(r1_weights)
        r1_ohe[np.arange(num), np.argmax(r1_weights, axis=1)] = 1.0 
        
        idx_r2_end = idx_r1_end + self.dim_r2
        r2_weights = generated_raw[:, idx_r1_end:idx_r2_end]
        r2_ohe = np.zeros_like(r2_weights)
        r2_ohe[np.arange(num), np.argmax(r2_weights, axis=1)] = 1.0
        
        cat_ohe_combined = np.concatenate([r1_ohe, r2_ohe], axis=1)
        r_ids_str = self.ohe.inverse_transform(cat_ohe_combined)
        r_ids_discrete = r_ids_str.astype(float).astype(int)
        
        final_features = np.concatenate([cont_real, metal_discrete, r3_discrete, r_ids_discrete], axis=1)
        
        columns = ['Cat(umol)', 'Al/M(molar)', 't/min', 'T/C', 'M_Zr', 'M_Ti', 'M_Hf', 'R3', 'R1对应编号', 'R2对应编号']
        df_generated = pd.DataFrame(final_features, columns=columns)
        
        df_generated['Target_AC_Class'] = condition[0]
        df_generated['Target_Mn_Class'] = condition[1]
        df_generated['Target_PDI_Class'] = condition[2]
        
        if save_file_path is not None:
            df_generated.to_csv(save_file_path, index=False, encoding='utf-8-sig')
            print(f"Finished, save to: {save_file_path}")
            
        return df_generated



class VectorFieldNet(Model):
    def __init__(self, input_dim, condition_dim, hidden_dim=256): 
        super().__init__()
        self.net = tf.keras.Sequential([
            layers.Dense(hidden_dim, activation='swish'),
            layers.Dense(hidden_dim, activation='swish'),
            layers.Dense(hidden_dim, activation='swish'),
            layers.Dense(input_dim) 
        ])

    def call(self, t, x, c):
        inputs = tf.concat([t, x, c], axis=-1)
        return self.net(inputs)

@tf.function
def train_step(model, optimizer, x1, c):
    batch_size = tf.shape(x1)[0]
    x0 = tf.random.normal(shape=tf.shape(x1))
    t = tf.random.uniform(shape=(batch_size, 1), minval=0.0, maxval=1.0)
    
    with tf.GradientTape() as tape:
        xt = (1.0 - t) * x0 + t * x1
        ut = x1 - x0
        vt = model(t, xt, c)
        loss = tf.reduce_mean(tf.square(vt - ut)) 
        
    gradients = tape.gradient(loss, model.trainable_variables)
    optimizer.apply_gradients(zip(gradients, model.trainable_variables))
    return loss

@tf.function
def generate_samples(model, condition, num_steps=100):
    batch_size = tf.shape(condition)[0]
    input_dim = model.net.layers[-1].units
    x = tf.random.normal((batch_size, input_dim))
    dt = 1.0 / num_steps
    
    for step in tf.range(num_steps):
        t_val = tf.cast(step, tf.float32) * dt
        t_tensor = tf.fill((batch_size, 1), t_val)
        v = model(t_tensor, x, condition)
        x = x + v * dt
    return x


@tf.function
def generate_samples_constrained(model, condition, fixed_target_batch, fixed_mask_batch, num_steps=50):
    batch_size = tf.shape(condition)[0]
    input_dim = model.net.layers[-1].units
    x_0 = tf.random.normal((batch_size, input_dim))
    x = x_0
    dt = 1.0 / num_steps
    
    for step in tf.range(num_steps):
        t_val = tf.cast(step, tf.float32) * dt
        
        # 1. x_t = (1-t)*x_0 + t*x_1
        x_theory = (1.0 - t_val) * x_0 + t_val * fixed_target_batch
        
        # 2. Cover ind of fixed_target
        x = tf.where(fixed_mask_batch, x_theory, x)
        
        # 3. predict velocity
        t_tensor = tf.fill((batch_size, 1), t_val)
        v = model(t_tensor, x, condition)
        
        # 4. ODE 
        x = x + v * dt
        
    x = tf.where(fixed_mask_batch, fixed_target_batch, x)
    return x