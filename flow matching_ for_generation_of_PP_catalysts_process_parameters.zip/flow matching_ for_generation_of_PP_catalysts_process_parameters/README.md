# Flow matching-based joint generation of metallocene catalysts and propylene polymerization conditions

"Prediction.ipynb" is the program corresponding to section 2.2 and 3.1 in the paper.
"Generation.ipynb" is the program corresponding to section 2.3 and 3.2 in the paper.
"flow0723.py" is called by "Generation.ipynb".